#ifndef BACKEND_GRAMMAR_H
#define BACKEND_GRAMMAR_H

#include <string>
#include <vector>

#include <boost/algorithm/string.hpp>
#include <boost/shared_ptr.hpp>

#define BACKEND_REQUEST '?'
#define BACKEND_REPLY '!'
#define BACKEND_REPLY_OK "ok"
#define BACKEND_REPLY_INVALID "invalid"
#define BACKEND_REPLY_FAIL "fail"
#define BACKEND_SEPARATOR ","

using namespace std;

namespace backend{

class GrammarError : public runtime_error
{
    public:
        GrammarError(const char* msg) : runtime_error(string(msg)){};
}; //class GrammarError

class Message
{
    public:
        Message(const char message_type,
                const char* name, 
                vector<string> arguments = vector<string>()) : 
            m_type(message_type),
            m_name(name),
            m_arguments(arguments){};
        Message(const Message&);
        Message& operator=(const Message&);
        virtual ~Message();
        virtual string toString() = 0;
    protected:
        char m_type;
        string m_name;
        vector<string> m_arguments;
}; //class Message

class Request : public Message
{
    public:
        Request() : Message(' ', "", vector<string>()){};
        Request(const char* name,
                vector<string> arguments = vector<string>()) : 
                Message(BACKEND_REQUEST,
                        name,
                        arguments){};
        Request(const Request&);
        Request& operator=(const Request&);
        virtual string toString();
}; //class Request

class Reply : public Message
{
    public:
        Reply() : Message(' ', "", vector<string>()),
                  m_code(""){};
        Reply(const char* name,
              const char* code,
              vector<string> arguments = vector<string>()) : 
              Message(BACKEND_REPLY,
                        name,
                        arguments),
              m_code(code){};
        Reply(const Reply&);
        Reply& operator=(const Reply&);
        virtual string toString();
    private:
        string m_code;
}; //class Reply

Reply
parseReply(const char*);

Request
parseRequest(const char*);

}; //namespace backend

#endif

