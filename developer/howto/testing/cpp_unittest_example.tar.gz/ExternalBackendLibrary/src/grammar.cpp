#include <sstream>

#include "grammar.h"

using namespace backend;

Message::~Message(){}

Message::Message(const Message& other)
{
    m_type = other.m_type;
    m_name = other.m_name;
    m_arguments = other.m_arguments;
}

Message&
Message::operator=(const Message& other)
{
    m_type = other.m_type;
    m_name = other.m_name;
    m_arguments = other.m_arguments;
    return *this;
}

Request::Request(const Request& other) : Message(other)
{}

Reply::Reply(const Reply& other) : Message(other)
{
    m_code = other.m_code;
}

Request&
Request::operator=(const Request& other)
{
    Message::operator=(other);
    return *this;
}

Reply&
Reply::operator=(const Reply& other)
{
    Message::operator=(other);
    m_code = other.m_code;
    return *this;
}

string
Request::toString()
{
    ostringstream output;
    output << m_type << m_name;
    for(vector<string>::iterator it = m_arguments.begin();
        it != m_arguments.end();
        ++it)
    {
        output << BACKEND_SEPARATOR << *it;
    }
    return output.str();
}

string
Reply::toString()
{
    ostringstream output;
    output << m_type << m_name << BACKEND_SEPARATOR << m_code;
    for(vector<string>::iterator it = m_arguments.begin();
        it != m_arguments.end();
        ++it)
    {
        output << BACKEND_SEPARATOR << *it;
    }
    return output.str();
}

Request
backend::parseRequest(const char* msg)
{
    string msg_string(msg);
    if(!(msg_string.length() >= 2))
        throw GrammarError("messages must contain at least 2 characters");
    vector<string> split_msg;
    boost::split(split_msg, msg_string, boost::is_any_of(BACKEND_SEPARATOR));
    char msg_type = split_msg[0][0];
    string msg_name = split_msg[0].substr(1, string::npos);
    vector<string> msg_arguments(++split_msg.begin(), split_msg.end());
    if(!(msg_type == BACKEND_REQUEST))
    {
        throw GrammarError("invalid type specifier");
    }
    return Request(msg_name.c_str(), msg_arguments);
}

Reply
backend::parseReply(const char* msg)
{
    string msg_string(msg);
    // first character must be BACKEND_REPLY
    if(!(msg_string[0] == BACKEND_REPLY))
        throw GrammarError("not a valid reply");
    // type + name + separator + reply_code
    if(!(msg_string.length() >= 4))
        throw GrammarError("reply must contain at least 4 characters");
    vector<string> split_msg;
    boost::split(split_msg, msg_string, boost::is_any_of(BACKEND_SEPARATOR));
    if(split_msg.size() < 2)
        throw GrammarError("reply must contain at least a name and a reply code");
    string msg_name = split_msg[0].substr(1, string::npos);
    string msg_code = split_msg[1];
    if((!(msg_code == BACKEND_REPLY_OK)) &&
       (!(msg_code == BACKEND_REPLY_FAIL)) &&
       (!(msg_code == BACKEND_REPLY_INVALID)))
        throw GrammarError("not a valid reply code");
    vector<string> msg_arguments(split_msg.begin() + 2, split_msg.end());
    return Reply(msg_name.c_str(), msg_code.c_str(), msg_arguments);
}

