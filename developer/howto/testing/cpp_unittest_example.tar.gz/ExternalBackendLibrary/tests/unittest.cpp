#include "gtest/gtest.h"

#include "grammar.h"

using namespace backend;

class Messages : public ::testing::Test {
    public:
        static const char *good_request, *bad_request, *good_reply_ok,
                          *good_reply_fail, *good_reply_invalid, *bad_reply_type,
                          *bad_reply_code;
};

const char * Messages::good_request = "?prova,1,2,3";
const char * Messages::bad_request = "#prova,1,2,3";
const char * Messages::good_reply_ok = "!prova,ok,1,2,3";
const char * Messages::good_reply_fail = "!prova,fail,1,2,3";
const char * Messages::good_reply_invalid = "!prova,invalid,1,2,3";
const char * Messages::bad_reply_type = "#prova,invalid,1,2,3";
const char * Messages::bad_reply_code = "!prova,badcode,1,2,3";

TEST(MessageTest, MessageRequestConstruction){
    Request request("myrequest");
    EXPECT_EQ("?myrequest", request.toString());
}

TEST_F(Messages, ParseGoodRequestMessage){
    Request msg;
    ASSERT_NO_THROW({
        msg = parseRequest(good_request);
    });
    EXPECT_EQ(good_request, msg.toString());
}

TEST_F(Messages, ParseGoodReply){
    Reply msg;
    ASSERT_NO_THROW({
        msg = parseReply(good_reply_ok);
        msg = parseReply(good_reply_fail);
        msg = parseReply(good_reply_invalid);
    });
    EXPECT_EQ(msg.toString(), good_reply_invalid);
}

TEST_F(Messages, ParseBadReply){
    EXPECT_THROW(parseReply(bad_reply_type), GrammarError);
    EXPECT_THROW(parseReply(bad_reply_code), GrammarError);
}


